/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.pop;



import org.junit.Test;
import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Scanner;

public class StudentTest {
    Scanner scanner = new Scanner(System.in);
   @Test

public void testSaveStudent() {
Student studentApp = new Student();
    
    // saved student
    int testStudentId = 12345;
    String testName = "John Doe";
    int testAge =  20;   ; // Invalid age
    
    String testEmail = "john@demo.com";
    String testCourse = "BCom in Business";

    // Save the student data 
    studentApp.saveStudent(testName, testStudentId, testAge, testEmail, testCourse);
}
    @Test
   
public void testSearchStudent() {
    // Create an instance of the Student class
    Student studentApp = new Student();

    // Define test data
    int testStudentId = 12345;
    String testName = "phakamani Nyoni";
    int testAge = 20;
    String testEmail = "will@gmail.com";
    String testCourse = "BCom in Business";

    // Create a StudentModel instance and add it to the students list
    StudentModel testStudent = new StudentModel(testName, testStudentId, testAge, testEmail, testCourse);
    studentApp.students.add(testStudent);

    // Redirect System.out to capture the output
    ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    System.setOut(new PrintStream(outContent));

    // Call the searchStudent method with the test student ID
    studentApp.searchStudent(testStudentId);

    // Verify that the output contains the expected student details
    String expectedOutput = "Name: " + testName + "\nStudent ID: " + testStudentId + "\nStudent Age: " + testAge + "\nStudent Email: " + testEmail + "\nStudent Course: " + testCourse;
    assertTrue(outContent.toString().contains(expectedOutput));

    // Reset System.out to its original state
    System.setOut(System.out);
}


    @Test
    public void testSearchStudent_StudentNotFound() {
        // Create an instance of the Student class
        Student studentApp = new Student();

        // Define test data
        int testStudentId = 5000;

        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        // searchStudent method with a student ID that doesn't exist
        studentApp.searchStudent(testStudentId);

        // check that the output indicates that the student was not found
        String expectedOutput = "Student with ID " + testStudentId + " not found.";
        assertEquals(expectedOutput, outContent.toString().trim());

        System.setOut(System.out);
    }


    @Test
    public void testDeleteStudent() {
        // Create an instance of the Student class
        Student studentApp = new Student();

        // Define test data
        int testStudentId = 5000;
        String testName = "John Doe";
        int testAge = 20;
        String testEmail = "john@example.com";
        String testCourse = "BCom in Business";

        // Create a StudentModel instance and add it to the students list
        StudentModel testStudent = new StudentModel(testName, testStudentId, testAge, testEmail, testCourse);
        studentApp.students.add(testStudent);

        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        System.setIn(new ByteArrayInputStream("y".getBytes()));
        studentApp.deleteStudent(testStudentId, new Scanner(System.in));

        // check that the student has been successfully deleted
        List<StudentModel> students = studentApp.students;
        assertTrue(students.isEmpty());

        // Reset System.out to its original state
        System.setOut(System.out);
        System.setIn(System.in);
    }
@Test
public void testDeleteStudent_StudentNotFound() {
    // Create an instance of the Student class
    Student studentApp = new Student();

    // Define test data
    int testStudentId = 5000; // Use an existing student ID
    String testName = "alley smith";
    int testAge = 20;
    String testEmail = "smith@demo.com";
    String testCourse = "BCom in Business";

    // Create a StudentModel instance and add it to the students list
    StudentModel testStudent = new StudentModel(testName, testStudentId, testAge, testEmail, testCourse);
    studentApp.students.add(testStudent);

    // Redirect System.out to capture the output
    ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    System.setOut(new PrintStream(outContent));

    
    System.setIn(new ByteArrayInputStream("y".getBytes()));
    studentApp.deleteStudent(5000, new Scanner(System.in)); // incorrect student ID

    // Verify that the output indicates that the student was not found
    String expectedOutput = "Student with ID 10000 not found."; // 
    assertEquals(expectedOutput, outContent.toString().trim());

    List<StudentModel> students = studentApp.students;
    assertFalse(students.isEmpty());

    // Reset System.out to its original state
    System.setOut(System.out);
    System.setIn(System.in);
}



    @Test
public void testStudentAge_Invalid() {
    // Create an instance of the Student class
    Student studentApp = new Student();

    // Define test data with an invalid age (less than 16)
    String testName = "phakamani Nyoni";
    int testStudentId = 12345;
    int testAge = 15; // An invalid age (less than 16)
    String testEmail = "Phakamani@example.com";
    String testCourse = "BCom in Business";

    // Redirect System.out to capture the output
    ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    System.setOut(new PrintStream(outContent));

    // Call the saveStudent method with an invalid age
    studentApp.saveStudent(testName, testStudentId, testAge, testEmail, testCourse);

    // Verify that the output indicates that the age is invalid
    String expectedOutput = "Invalid input. Student age must be greater than or equal to 16.";
    assertEquals(expectedOutput, outContent.toString().trim());

    // Reset System.out to its original state
    System.setOut(System.out);
}

    

    @Test(expected = NumberFormatException.class)
public void testStudentAge_InvalidCharacter() {
    Student studentApp = new Student();
    
    // Define test data with an invalid age character "a"
    int testStudentId = 12345;
    String testName = "phakamani";
    String testAge = "a"; // 
    
    String testEmail = "Phakamani@demo.com";
    String testCourse = "BCom in Business";

    // Save the student data 
    studentApp.saveStudent(testName, testStudentId, Integer.parseInt(testAge), testEmail, testCourse);
}

}
