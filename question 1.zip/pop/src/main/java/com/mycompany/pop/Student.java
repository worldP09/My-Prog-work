/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pop;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Student {
    static  ArrayList<StudentModel> students = new ArrayList<>();
    public static List<String> name = new ArrayList<>();
    public static List<String> studentId = new ArrayList<>();
    public static List<String> age = new ArrayList<>();
    public static List<String> email = new ArrayList<>();
    public static List<String> course = new ArrayList<>();
    
    
    static private int studentCount = 0;
    static private String stars = "************************************************************";
    public static void main(String[] args) {
        Student studentApp = new Student();
        Scanner MyOutput = new Scanner(System.in);

        while (true) {
            System.out.println(stars);
            System.out.println("Student Management Application");
            System.out.println(stars);
            System.out.println("Please select one of the following menu items:"
                                +"\n1. Capture a new student"
                                +"\n2. Search for a student"
                                +"\n3. Delete a student"
                                +"\n4. Print student details"
                                +"\n5. Exit application");
            System.out.print(stars+"\nEnter your choice: ");
            int choice = MyOutput.nextInt();
            MyOutput.nextLine();  // Consume the newline character
            
            switch (choice) {
                case 1:
                    
                    System.out.print("\nEnter student name: ");
                    String name = MyOutput.next();
                    int studentId, age;
                    while (true) {
                        System.out.print("Enter student ID: ");
                        if (MyOutput.hasNextInt()) {
                            studentId = MyOutput.nextInt();
                            break;
                        } else {
                            System.out.println("Invalid input. Please enter a valid student ID (numbers only).");
                            MyOutput.next(); // Consume the invalid input
                        }
                    }
                    while (true) {
                        System.out.print("Enter student age: ");
                        if (MyOutput.hasNextInt()) {
                            age = MyOutput.nextInt();
                            if (age >= 16) {
                                break;
                            } else {
                                System.out.println("Invalid input. Student age must be greater than or equal to 16.");
                            }
                        } else {
                            System.out.println("Invalid input. Please enter a valid student age (numbers only).");
                            MyOutput.next(); // Consume the invalid input
                        }
                    }
                    
                    System.out.print("Enter student email: ");
                    String email = MyOutput.next();

                    System.out.print("Enter student course: ");
                    String course = MyOutput.next();
                    studentApp.saveStudent(name, studentId, age, email, course);
                    break;
                case 2:
                    System.out.print("Enter Student ID to search: ");
                    int searchId;
                    while (true) {
                        if (MyOutput.hasNextInt()) {
                            searchId = MyOutput.nextInt();
                            break;
                        } else {
                            System.out.println("Invalid input. Please enter a valid student ID (numbers only).");
                            MyOutput.next(); // Consume the invalid input
                        }
                    }
                    studentApp.searchStudent(searchId);
                    break;
                case 3:
                    System.out.print("Enter Student ID to delete: ");
                    int deleteId;
                    while (true) {
                        if (MyOutput.hasNextInt()) {
                            deleteId = MyOutput.nextInt();
                            break;
                        } else {
                            System.out.println("Invalid input. Please enter a valid student ID (numbers only).");
                            MyOutput.next(); // Consume the invalid input
                        }
                    }
                    studentApp.deleteStudent(deleteId, MyOutput);
                    break;
                case 4:
                    studentApp.studentReport();
                    break;
                case 5:
                    studentApp.exitStudentApplication();
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
    
public void saveStudent(String name, int studentId, int age, String email, String course) {
     if (age < 16) {
        System.out.println("Invalid input. Student age must be greater than or equal to 16.");
        return; 
    }
// StudentModel object with details.
    StudentModel student = new StudentModel(name, studentId, age, email, course);

    // Add  student 
    students.add(student);

    // Increment the studentCount.
    studentCount++;

    // Print a success message.
    System.out.println("Student details have been saved successfully.");
}
    public void searchStudent(int searchId) {
        for (StudentModel student : students) {
            if (student.getStudentId() == searchId) {
                System.out.println("Name: " + student.getName()
                                            +"\nStudent ID: " + student.getStudentId()
                                            +"\nStudent Age: " + student.getAge()
                                            +"\nStudent Email: " + student.getEmail()
                                            +"\nStudent Course: " + student.getCourse());
                return;
            }
        }
        System.out.println("Student with ID " + searchId + " not found.");
    }

    public void deleteStudent(int deleteId, Scanner scanner) {
        StudentModel studentToDelete = null;
        for (StudentModel student : students) {
            if (student.getStudentId() == deleteId) {
                studentToDelete = student;
                break;
            }
        }

        if (studentToDelete != null) {
            System.out.println(stars+"\nStudent found:"
                                    +"\nName: " + studentToDelete.getName()
                                    +"\nStudent ID: " + studentToDelete.getStudentId()
                                    +"\nStudent Age: " + studentToDelete.getAge()
                                    +"\nStudent Email:" +studentToDelete.getEmail()
                                    +"\nStudent Course:" +studentToDelete.getCourse()   
                                    +"\n"+stars);

            System.out.print("Do you want to delete this student? (Y/N): ");
            String confirm = scanner.nextLine().trim().toLowerCase();

            if (confirm.equals("y")) {
                students.remove(studentToDelete);
                System.out.println("Student with ID " + deleteId + " has been deleted.");
            } else {
                System.out.println("Deletion canceled. Student was not deleted.");
            }
        } else {
            
            System.out.println(stars+"\nStudent with ID " + deleteId + " not found.\n"+stars+"\n");
        }
    }

    public void studentReport() {
        System.out.println("Student Report:");
        if (students.isEmpty()) {
            System.out.println("No students in the system.");
        } else {
            for (StudentModel student : students) {
                System.out.println(stars
                                  +"\nName: " + student.getName()
                                  +"\nStudent ID: " + student.getStudentId()
                                  +"\nStudent Age: " + student.getAge()
                                  +"\nStudent Email: " + student.getEmail()
                                  +"\nStudent COurse: " + student.getCourse()
                                  );
                System.out.println("Total Students: " + studentCount);
            }
        }
    }

    public void exitStudentApplication() {
        System.out.println("Exiting the application.");
        System.exit(0);
    }
}


 class StudentModel {
    private String name;
    static private int studentId;
    private int age;
    private String email;
    private String course;

    public StudentModel(String name, int studentId, int age, String email, String course) {
        this.name = name;
        this.studentId = studentId;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    public String getName() {
        return name;
    }

    public int getStudentId() {
        return studentId;
    }

    public int getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public String getCourse() {
        return course;
    }
}
