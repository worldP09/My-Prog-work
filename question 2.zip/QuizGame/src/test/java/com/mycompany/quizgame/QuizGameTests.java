/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.quizgame;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertArrayEquals;

public class QuizGameTests {

    @Test
    public void testQuestion() {
        Question question = new Question("What is the capital of France?", 1);
        assertEquals("What is the capital of France?", question.getQuestionText());
        assertEquals(1, question.getCorrectAnswer());
    }

    @Test
    public void testMultipleChoiceQuestion() {
        String[] options = {"Paris", "Madrid", "Berlin"};
        MultipleChoiceQuestion question = new MultipleChoiceQuestion("What is the capital of France?", options, 1);
        assertArrayEquals(options, question.getOptions());
    }

    @Test
    public void testQuiz() {
        Question[] questions = {
            new Question("Question 1", 1),
            new Question("Question 2", 2)
        };
        Quiz quiz = new Quiz(questions);

        assertEquals(true, quiz.hasNextQuestion());
        quiz.answerCurrentQuestion(1);
        assertEquals(true, quiz.hasNextQuestion());
        quiz.answerCurrentQuestion(2);
        assertEquals(false, quiz.hasNextQuestion());

        assertEquals(2, quiz.getScore());
    }
}
