/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quizgame;



  import java.util.Scanner;

public class QuizGameApp {
    public static void main(String[] args) {
        // Define an array of questions
        Question[] questions = {
            new MultipleChoiceQuestion("What is the capital of France?", new String[]{"Paris", "Madrid", "Berlin"}, 1),
            new MultipleChoiceQuestion("Which planet is known as the Red Planet?", new String[]{"Mars", "Venus", "Jupiter"}, 1),
            new MultipleChoiceQuestion("What is the largest mammal on Earth?", new String[]{"Elephant", "Blue Whale", "Giraffe"}, 2)
        };

        Quiz quiz = new Quiz(questions);

        while (quiz.hasNextQuestion()) {
            quiz.displayCurrentQuestion();
            // Get user input for the answer
            int userAnswer = getUserInput();
            quiz.answerCurrentQuestion(userAnswer);
        }

        // Display the final score
        System.out.println("Your final score: " + quiz.getScore() + " out of " + questions.length);
    }

    public static int getUserInput() {
        Scanner scanner = new Scanner(System.in);

        int userAnswer = 0;
        boolean validInput = false;

        while (!validInput) {
            System.out.print("Enter your answer (1, 2, or 3): ");
            if (scanner.hasNextInt()) {
                userAnswer = scanner.nextInt();
                if (userAnswer >= 1 && userAnswer <= 3) {
                    validInput = true;
                } else {
                    System.out.println("Invalid input. Please enter 1, 2, or 3.");
                }
            } else {
                scanner.nextLine(); // Clear the input buffer
                System.out.println("Invalid input. Please enter a number (1, 2, or 3).");
            }
        }

        return userAnswer;
    }
}

class Question {
    private String questionText;
    private int correctAnswer;

    public Question(String questionText, int correctAnswer) {
        this.questionText = questionText;
        this.correctAnswer = correctAnswer;
    }

    public String getQuestionText() {
        return questionText;
    }

    public int getCorrectAnswer() {
        return correctAnswer;
    }
}

class MultipleChoiceQuestion extends Question {
    private String[] options;

    public MultipleChoiceQuestion(String questionText, String[] options, int correctAnswer) {
        super(questionText, correctAnswer);
        this.options = options;
    }

    public String[] getOptions() {
        return options;
    }
}

class Quiz {
    private Question[] questions;
    private int currentQuestionIndex;
    private int score;

    public Quiz(Question[] questions) {
        this.questions = questions;
        this.currentQuestionIndex = 0;
        this.score = 0;
    }

    public boolean hasNextQuestion() {
        return currentQuestionIndex < questions.length;
    }

    public void displayCurrentQuestion() {
        if (hasNextQuestion()) {
            Question question = questions[currentQuestionIndex];
            System.out.println("Question " + (currentQuestionIndex + 1) + ": " + question.getQuestionText());

            if (question instanceof MultipleChoiceQuestion) {
                String[] options = ((MultipleChoiceQuestion) question).getOptions();
                for (int i = 0; i < options.length; i++) {
                    System.out.println((i + 1) + ". " + options[i]);
                }
            }
        } else {
            System.out.println("End of the quiz.");
        }
    }

    public void answerCurrentQuestion(int userAnswer) {
        if (hasNextQuestion()) {
            Question question = questions[currentQuestionIndex];
            if (userAnswer == question.getCorrectAnswer()) {
                System.out.println("Correct! You earn a point.");
                score++;
            } else {
                System.out.println("Incorrect. The correct answer was: " + (question.getCorrectAnswer()));
            }
            currentQuestionIndex++;
        }
    }

    public int getScore() {
        return score;
    }
}
